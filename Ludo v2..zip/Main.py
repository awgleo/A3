'''
Ludo Game in Python using Pygame

Requirements:
- Python 3.x
- Pygame (install via `pip install pygame`)

Usage:
    python3 ludo_game.py

Controls:
- Click the dice to roll.
- Click your piece to move when prompted.

This script implements a complete Ludo game with:
- 4 players: Green, Yellow, Red, Blue
- Standard Ludo rules (roll 6 to exit base, capture, safe spots, finals)
- Animated piece movement and dice roll
- Modular code structure following PEP8
'''

import sys
import random
import pygame
from pygame.locals import QUIT, MOUSEBUTTONDOWN

# -- Constants --------------------------------------------------------------
CELL_SIZE = 40
GRID_SIZE = 15
BOARD_PIXELS = CELL_SIZE * GRID_SIZE
UI_HEIGHT = 100
WINDOW_WIDTH = BOARD_PIXELS
WINDOW_HEIGHT = BOARD_PIXELS + UI_HEIGHT
FPS = 60

# Colors
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
WHITE = (255, 255, 255)
GREEN = (0, 200, 0)
YELLOW = (200, 200, 0)
RED = (200, 0, 0)
BLUE = (0, 0, 200)
COLORS = {'green': GREEN, 'yellow': YELLOW, 'red': RED, 'blue': BLUE}

# Path geometry (grid coords)
PATH_CELLS = [
    (6, 0), (6, 1), (6, 2), (6, 3), (6, 4), (6, 5),
    (5, 6), (4, 6), (3, 6), (2, 6), (1, 6), (0, 6),
    (0, 7), (0, 8), (1, 8), (2, 8), (3, 8), (4, 8), (5, 8),
    (6, 9), (6,10), (6,11), (6,12), (6,13), (6,14),
    (7,14), (8,14), (8,13), (8,12), (8,11), (8,10), (8, 9),
    (9, 8), (10,8), (11,8), (12,8), (13,8), (14,8),
    (14,7), (14,6), (13,6), (12,6), (11,6), (10,6), (9, 6),
    (8, 5), (8, 4), (8, 3), (8, 2), (8, 1), (8, 0), (7, 0)
]
START_OFFSET = {'green': 0, 'yellow': 13, 'red': 26, 'blue': 39}
SAFE_INDICES = {0, 8, 13, 21, 26, 34, 39, 47}
FINAL_CELLS = {
    'green': [(7,1),(7,2),(7,3),(7,4),(7,5),(7,6)],
    'yellow':[(13,7),(12,7),(11,7),(10,7),(9,7),(8,7)],
    'red':   [(7,13),(7,12),(7,11),(7,10),(7,9),(7,8)],
    'blue':  [(1,7),(2,7),(3,7),(4,7),(5,7),(6,7)]
}
HOME_CELL = (7,7)

BASE_CELLS = {
    'green': [(1,1),(1,3),(3,1),(3,3)],
    'yellow':[(11,1),(11,3),(13,1),(13,3)],
    'red':   [(11,11),(11,13),(13,11),(13,13)],
    'blue':  [(1,11),(1,13),(3,11),(3,13)]
}

# -- Classes ----------------------------------------------------------------
class Piece:
    """Represents a single Ludo piece."""
    def __init__(self, color, idx):
        self.color = color
        self.idx = idx
        self.step = -1  # -1=base, 0-51=path, 52-57=final, 58=home
        self.anim_pos = None

    def at_base(self): return self.step == -1
    def at_home(self): return self.step == 58
    def can_move(self, roll):
        if self.at_home(): return False
        if self.at_base(): return roll == 6
        return self.step + roll <= 58

    def move(self, roll):
        if self.at_base() and roll == 6:
            self.step = 0
        elif self.step >= 0:
            self.step += roll

    def get_grid_pos(self):
        if self.step == -1:
            return BASE_CELLS[self.color][self.idx]
        if 0 <= self.step <= 51:
            abs_i = (START_OFFSET[self.color] + self.step) % len(PATH_CELLS)
            return PATH_CELLS[abs_i]
        if 52 <= self.step <= 57:
            return FINAL_CELLS[self.color][self.step - 52]
        return HOME_CELL

class Dice:
    """Represents the dice with roll and animation."""
    def __init__(self):
        self.value = None
        self.rolling = False
        self.roll_frames = 0

    def roll(self):
        self.rolling = True
        self.roll_frames = 15

    def update(self):
        if self.rolling:
            if self.roll_frames > 0:
                self.value = random.randint(1, 6)
                self.roll_frames -= 1
            else:
                self.rolling = False

    def draw(self, surf):
        size = 80
        x = WINDOW_WIDTH//2 - size//2
        y = BOARD_PIXELS + (UI_HEIGHT - size)//2
        pygame.draw.rect(surf, WHITE, (x, y, size, size), border_radius=8)
        if self.value:
            pip = size // 8
            coords = []
            mid = (x+size//2, y+size//2)
            offs = size // 4
            if self.value in (1,3,5): coords.append(mid)
            if self.value in (2,3,4,5,6): coords += [(x+offs, y+offs), (x+size-offs, y+size-offs)]
            if self.value in (4,5,6): coords += [(x+offs, y+size-offs), (x+size-offs, y+offs)]
            if self.value == 6: coords += [(x+offs, y+size//2), (x+size-offs, y+size//2)]
            for cx, cy in coords:
                pygame.draw.circle(surf, BLACK, (cx, cy), pip)

class Player:
    def __init__(self, color):
        self.color = color
        self.pieces = [Piece(color, i) for i in range(4)]
    def has_moves(self, roll): return any(p.can_move(roll) for p in self.pieces)
    def all_home(self): return all(p.at_home() for p in self.pieces)

class Board:
    def draw(self, surf):
        surf.fill(BLACK)
        pygame.draw.rect(surf, GRAY, (0,0,BOARD_PIXELS,BOARD_PIXELS), 4)
        for color, cells in BASE_CELLS.items():
            for c,r in cells:
                pygame.draw.rect(surf, COLORS[color], (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE))
                pygame.draw.rect(surf, WHITE, (c*CELL_SIZE+5, r*CELL_SIZE+5, CELL_SIZE-10, CELL_SIZE-10), 2)
        for idx,(c,r) in enumerate(PATH_CELLS):
            pygame.draw.rect(surf, GRAY, (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE))
            if idx in SAFE_INDICES:
                pygame.draw.circle(surf, WHITE, (c*CELL_SIZE+CELL_SIZE//2, r*CELL_SIZE+CELL_SIZE//2), 5)
        for cells in FINAL_CELLS.values():
            for c,r in cells:
                pygame.draw.rect(surf, COLORS[next(color for color,cells_ in FINAL_CELLS.items() if cells_==cells)], (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE))
        cx,cy = HOME_CELL
        pygame.draw.rect(surf, WHITE, (cx*CELL_SIZE, cy*CELL_SIZE, CELL_SIZE, CELL_SIZE))

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Ludo Game")
        self.clock = pygame.time.Clock()
        self.board = Board()
        self.dice = Dice()
        self.players = [Player(c) for c in ('green','yellow','red','blue')]
        self.current = 0
        self.roll_occurred = False
        self.move_phase = False
        self.selected_piece = None
        self.font = pygame.font.SysFont(None, 36)

    def loop(self):
        while True:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == QUIT: pygame.quit(); sys.exit()
                if event.type == MOUSEBUTTONDOWN: self.handle_click(event.pos)
            self.dice.update()
            self.draw()
            pygame.display.flip()

    def handle_click(self, pos):
        x,y = pos
        size = 80
        dx = WINDOW_WIDTH//2 - size//2
        dy = BOARD_PIXELS + (UI_HEIGHT-size)//2
        if dx<=x<=dx+size and dy<=y<=dy+size:
            self.try_roll()
        elif self.move_phase and not self.selected_piece:
            self.try_select_piece(pos)

    def try_roll(self):
        if not self.roll_occurred and not self.dice.rolling:
            self.dice.roll()
            self.roll_occurred = True
            self.move_phase = False

    def try_select_piece(self, pos):
        for piece in self.players[self.current].pieces:
            col,row = piece.get_grid_pos()
            px,py = row*CELL_SIZE, col*CELL_SIZE
            cx = col*CELL_SIZE+CELL_SIZE//2
            cy = row*CELL_SIZE+CELL_SIZE//2
            if (pos[0]-cx)**2 + (pos[1]-cy)**2 <= (CELL_SIZE//2)**2:
                if piece.can_move(self.dice.value):
                    self.selected_piece = piece
                    self.animate_move(piece, self.dice.value)
                break

    def animate_move(self, piece, roll):
        old_step = piece.step
        piece.move(roll)
        new_step = piece.step
        for i in range(old_step+1, new_step+1):
            temp = Piece(piece.color, piece.idx)
            temp.step = i
            target = temp.get_grid_pos()
            self.smooth_move(piece, (target[0]*CELL_SIZE+CELL_SIZE//2, target[1]*CELL_SIZE+CELL_SIZE//2))
        self.capture(piece)
        if self.dice.value != 6 or not self.players[self.current].has_moves(6):
            self.current = (self.current + 1) % 4
        self.roll_occurred = False
        self.selected_piece = None

    def smooth_move(self, piece, target):
        if not piece.anim_pos:
            g = piece.get_grid_pos()
            piece.anim_pos = (g[0]*CELL_SIZE+CELL_SIZE//2, g[1]*CELL_SIZE+CELL_SIZE//2)
        start = piece.anim_pos
        dx,dy = target[0]-start[0], target[1]-start[1]
        frames = 10
        for i in range(frames):
            frac = (i+1)/frames
            piece.anim_pos = (start[0]+dx*frac, start[1]+dy*frac)
            self.draw(); pygame.display.flip(); self.clock.tick(FPS)
        piece.anim_pos = target

    def capture(self, mover):
        pos = mover.get_grid_pos()
        if 0 <= mover.step <= 51:
            # find path index
            if pos in PATH_CELLS:
                idx = PATH_CELLS.index(pos)
                if idx not in SAFE_INDICES:
                    for pl in self.players:
                        if pl.color != mover.color:
                            for pc in pl.pieces:
                                if pc.get_grid_pos() == pos:
                                    pc.step = -1

    def draw(self):
        self.board.draw(self.screen)
        for pl in self.players:
            for pc in pl.pieces:
                x,y = pc.anim_pos if pc.anim_pos else (pc.get_grid_pos()[0]*CELL_SIZE+CELL_SIZE//2, pc.get_grid_pos()[1]*CELL_SIZE+CELL_SIZE//2)
                pygame.draw.circle(self.screen, COLORS[pc.color], (int(x),int(y)), CELL_SIZE//2-5)
        self.dice.draw(self.screen)
        msg = f"{self.players[self.current].color.title()} turn. "
        if self.roll_occurred:
            msg += f"Roll: {self.dice.value}. Select piece."
        else:
            msg += "Click dice."
        text = self.font.render(msg, True, WHITE)
        self.screen.blit(text, (10, BOARD_PIXELS+10))

if __name__ == '__main__':
    Game().loop()
